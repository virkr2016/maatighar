# tribalcart
Temporary Website for TribalCart

It's a static temporary website for branding of a tribal art business named TribalCart.
